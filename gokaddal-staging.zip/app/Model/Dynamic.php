<?php
class Dynamic extends AppModel {
	public $useTable = false;
}