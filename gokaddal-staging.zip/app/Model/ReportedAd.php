<?php

class ReportedAd extends AppModel {
	
}