<?php

class NewsLike extends AppModel {

}
