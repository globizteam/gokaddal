<?php
class StoreOpenHour extends AppModel {

}
?>