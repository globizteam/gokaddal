<?php

class Organization extends AppModel {

}
