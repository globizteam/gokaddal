<?php
class Designation extends AppModel {
	
}