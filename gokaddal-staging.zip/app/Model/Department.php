<?php

class Department extends AppModel {

}
