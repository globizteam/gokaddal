<?php

class ProductType extends AppModel {
    


}
