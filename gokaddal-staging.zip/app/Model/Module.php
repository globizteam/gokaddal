<?php
class Module extends AppModel {
	
}