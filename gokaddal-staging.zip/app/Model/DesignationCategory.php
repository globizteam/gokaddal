<?php
class DesignationCategory extends AppModel {
	public $useTable = 'designation_categories';
}