<?php

class Category extends AppModel {
    
	public $hasMany = 'ProviderService';

	 //    public $belongsTo = [
		//      'ProviderService' => [
		//         'className' => 'ProviderService',
		//         // 'foreignKey' => 'category_id'
		//     ]
		// ];

}
