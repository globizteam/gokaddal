$(document).ready(function(){
	 $('.datepicker').datepicker({
		format: 'mm/dd/yyyy',
		startDate: '-3d'
	});
 });